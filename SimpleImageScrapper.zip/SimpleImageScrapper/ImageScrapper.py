
import urllib.request,urllib.response,urllib.error
import tkinter as tk
from tkinter import ttk
from bs4 import BeautifulSoup
import ssl
# ---------------------------------------------------------

# Ignore SSL certificate errors
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE
# ---------------------------------------------------------

# Variable declaration
validUrl=list()
FILE_PATH='images/'
fh=None


# ---------------------------------------------------------


# ---------------------------------------------------------

# Function to download images
def url_to_jpg(i,url,file_path):
    file_name='image-{}.jpg'.format(i)
    full_path='{}{}'.format(file_path,file_name)
    urllib.request.urlretrieve(url,full_path)
    print('{} saved.'.format(file_name))
    return None
# ---------------------------------------------------------

win=tk.Tk()
win.title("Simple Wallpaper scrapper")
lbl = ttk.Label(win, text = "Enter the link from wallpapermemory.com (eg.https://wallpapermemory.com/desktop-backgrounds/...):").grid(column = 0, row = 0)


# Click event
def click():
    try:
        print("Retriveing...." + name.get())
        fh = urllib.request.urlopen(name.get(), context=ctx).read()
        soup = BeautifulSoup(fh, 'html.parser')

        # Retrieve all of the img tags
        tags = soup('img')

        for tag in tags:
            # Look at the parts of a tag
            url = tag.get('src')
            print('URL:', tag.get('src', None))
            if (url.startswith('/uploads')):
                validUrl.append(url)
            else:
                continue
        print(len(validUrl))

        for u in validUrl:
            url_to_jpg(u[13:-4], 'https://wallpapermemory.com' + u, FILE_PATH)
    except:
        print("Enter Valid URL!!!")
        return



name = tk.StringVar()

# Textbox widget
nameEntered = ttk.Entry(win, width = 100, textvariable = name).grid(column = 0, row = 1)
# Button widget
button = ttk.Button(win, text = "submit", command = click).grid(column = 1, row = 1)

win.mainloop()



